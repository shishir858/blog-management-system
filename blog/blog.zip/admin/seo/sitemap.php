// Sitemap management
// TODO: Implement sitemap generation

<?php
// Sitemap management
// Blog sitemap is now available at /sitemap-blog.xml.php
echo '<h2>Blog Sitemap</h2>';
echo '<p>Blog sitemap is generated at <a href="/sitemap-blog.xml.php" target="_blank">/sitemap-blog.xml.php</a></p>';
echo '<h3>Other Sitemaps</h3>';
echo '<ul>';
echo '<li><a href="/sitemap.xml" target="_blank">Main Sitemap Index</a></li>';
echo '<li><a href="/sitemap-pages.xml" target="_blank">Pages Sitemap</a></li>';
echo '</ul>';
